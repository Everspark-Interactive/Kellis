<?php

/**

 * The template for displaying the footer.

 *

 * Contains the closing of the #content div and all content after

 *

 * @package WPCharming

 */

global $wpc_option;
?>

<!--Footer Section Start-->
<?php if ( is_active_sidebar( 'footer-cta' )){
	
 dynamic_sidebar('footer-cta');
 
} ?>
<!--<div class="cta-section">
    <div class="container">
        <div class="cta-title">get legal representation you deserve for your dui case!</div>
        <a class="btn btn-primary" href="http://www.pennsylvania-dui-lawyer.com/beta/contact-us/">CONTACT US</a>
    </div>
</div>-->

   <footer class="section-footer">

    <div class="container">

        <div class="row">
        
        	<?php if ( $wpc_option['footer_widgets'] ) { ?>

				<?php $footer_columns = $wpc_option['footer_columns']; ?>

		<?php if ( is_active_sidebar( 'footer1' ) || is_active_sidebar( 'footer2' ) || is_active_sidebar( 'footer3' ) ) { ?>

					
						<?php 

				for ( $count = 1; $count <= $footer_columns; $count++ ) {

							?>
                        <div class="col-lg-<?php echo $footer_columns ?> col-md-<?php echo $footer_columns ?> col-sm-<?php echo $footer_columns ?>">
					<div class="widget clearfix <?php if($count==1){echo 'firstwidget';}elseif($count==2){echo 'middwidget';}elseif($count==3){echo 'lastwidget';}?>">

						<?php dynamic_sidebar('footer'.$count);?>

					</div></div>
							<?php
						}
						?>
					</div>
				<?php } ?>
			<?php } ?>
        
        

<!--            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-left">

                <div class="widget clearfix firstwidget">

                    <div class="widget-title">

                        <h3>About Kellis Law Firm</h3>

                    </div>

                    <div class="textwidget">

                        <p>Kellis Law Firm is a practice focused on DUI law and was founded by attorney Steven Kellis. Steven has over 20 years of experience and will put his expertise to work for your DUI case.</p>
                       
                    </div>

                </div>

            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-left text-center">

                <div class="widget middwidget clearfix">

                    <div class="textwidget">

                        <div class="foo-logo"><img src="<?php //echo get_template_directory_uri(); ?>/new-home/images/pennsylvania-dui-lawyer.png" alt="Pennsylvania-Dui-Lawyer"></div>

                        <p>Two Penn Center Plaza<br> 1500 John F. Kennedy Blvd. Suite 900<br> Philadelphia, PA 19102</p>

                        <a href="http://www.pennsylvania-dui-lawyer.com/beta/directions" class="btn-getdir">Get Directions</a>
                    </div>

                </div>

            </div>

            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-left">

                <div class="widget lastwidget clearfix">

                    <div class="widget-title">

                        <h3>Free Initial Consultation!</h3>

                    </div>

                    <div class="textwidget">

                        <p>We accept most forms of payment.</p>

                        <p><img src="<?php //echo get_template_directory_uri(); ?>/new-home/images/paypal.png" alt="PayPal"></p>

                        <div class="foot-info"><a href="tel:2159401200">(215) 940-1200</a></div>

                        <div class="foot-info2"><a href="mailto:steven@kellislaw.com">steven@kellislaw.com</a></div>

                    </div>

                </div>

            </div>-->

        </div>
        <div class="container">
            <div class="row">
				<?php if ( is_active_sidebar( 'footer-copyright' )){
                    
                 dynamic_sidebar('footer-copyright');
                 
                } ?>
            </div>
        </div>

    </div>

</footer>

<!--Footer Section End-->
</div>
<!-- Main wrapper End -->
<?php wp_footer(); ?>
<!--<script src="<?php //echo get_template_directory_uri(); ?>/new-home/js/jquery.js"></script>-->

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/bootstrap.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/full-width-menu/js/webslidemenu.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/jquery.parallax.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/application.js"></script>


<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/new-home/js/s3Capcha1.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/jquery.maskedinput.js" type="text/javascript"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/jquery.validate.min.js" type="text/javascript"></script>

<script>

// MAP

jQuery(document).ready(function($) {

 $('#capcha').s3Capcha();

 $("#phone").mask("(999) 999-9999");

 $("#caseconsultationform1").validate({		

		errorElement: "lable",

		submitHandler: function(form)

		{

			$.ajax({

				url: "sendcaseconsultation.php",

				type: "POST",

				data:  $("#caseconsultationform1").serialize(),

				success: function(data)

				{ 					

					if(data==2)

					{

						alert("Please select correct captcha code.");

						return false;

					}

					else

					{

						$("#SUCCONMSG").html(data);						

						$('#caseconsultationform1').each (function(){

							this.reset();

						});

						return false;

					}

				}

			});

			return false;

		}

	});

});

$( ".captchaimg" ).click(function() {

	$(".captchaimg").removeClass("active");

 $(this).addClass("active");

});

</script>

<script>

    $('#myCarousel').carousel({

        interval: false //changes the speed

        //interval: 5000 //changes the speed samail		

    })

</script>

<script type="text/javascript">

var window1 = $(window); 

$(window).resize(function(){    

var height = $(window).height();

   if(jQuery(window).width()<=479)

	{

		var height = 650;

	}

	else if(jQuery(window).width()<=840)

	{

		var height = 550;

	}

	else if(jQuery(window).width()<=991)

	{

		var height = 550;

	}

	else if(jQuery(window).width()>=992)

	{

		var height = 763;

	}

	else

	{
		var height = jQuery(window).height();
	}	 

   $('#myCarousel').css("height", height);

}).resize();

</script>

<!-- Owl Carousel script files -->

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/owl.carousel.js"></script>

<script>

$(document).ready(function() {

$("#owl-testimonial").owlCarousel({

	items : 2,

	lazyLoad : true,

	pagination : false,

	navigation : true,

	itemsDesktop : [1199, 2],

	itemsDesktopSmall : [979, 2],

	 itemsTablet : [768, 1]

	});

});

</script>

<!--vscroll elastislide-->

<script>

  	imgBList=new Array();

	imgAList=new Array();	

	imgBList[0]="uploads/before/1400926866_BackyardView1.jpg";

	imgAList[0]="uploads/after/1400926866_BackyardView1.jpg";

	imgBList[1]="uploads/before/1400927213_Den1.jpg";

	imgAList[1]="uploads/after/1400927213_Den1.jpg";

	imgBList[2]="uploads/before/1400927274_DownstairsBath1b.jpg";

	imgAList[2]="uploads/after/1400927274_DownstairsBath1b.jpg";

</script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/modernizr.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/beforeafterscript/jquery.event.move.js"></script>

<script src="<?php echo get_template_directory_uri(); ?>/new-home/js/beforeafterscript/jquery.twentytwenty.js"></script>

<script>

$(window).load(function(){

  document.getElementById('imgbox1').src=imgBList[0];

  document.getElementById('imgbox2').src=imgAList[0];

  $(".twentytwenty-container[data-orientation!='vertical']").twentytwenty({default_offset_pct: 0.5});

});

</script>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/new-home/js/vscroll/jquerypp.custom.js"></script>

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/new-home/js/vscroll/jquery.elastislide.js"></script>

<script type="text/javascript">

	$('#carousel').elastislide( {

		orientation : 'horizontal'

	});

</script>

<script>

function changeImg(val)

{

	$('#loading_area').show();

	$('#loading_area').html('<img src="<?php echo get_template_directory_uri(); ?>/new-home/images/ajax-loader.gif" class="thumbnail" />');

	$('.twentytwenty-container').hide();

   	setTimeout(function() {

	$('.twentytwenty-container').show();

	$('#loading_area').hide();

	var af=document.getElementById('slid_af_'+val).value;

	document.getElementById('imgbox2').src=af;

	var bf=document.getElementById('slid_'+val).src;

	document.getElementById('imgbox1').src=bf;

	}, 5000);

}

</script>

<!--vscroll elastislide-->


</body>

</html>